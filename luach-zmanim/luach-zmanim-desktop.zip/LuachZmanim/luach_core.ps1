﻿# לוח זמנים - תוכנת הרקע (PowerShell, בלי קובץ מהודר).  נוצר ע"י netivdosIL
#   הפעלה רגילה:        luach_core.ps1             (פותח את הלוח בדפדפן)
#   הפעלה ברקע:         luach_core.ps1 -Background (בלי לפתוח דפדפן - לעליית Windows)
#   עצירה:              POST http://127.0.0.1:57870/api/quit
# שרת מקומי, נתונים, גיבוי יומי, יומן, ותזכורות קופצות מונפשות.
param([switch]$Background)

# החלונות הקופצים דורשים תהליכון STA
if ([Threading.Thread]::CurrentThread.GetApartmentState() -ne 'STA') {
  $a = '-NoProfile -STA -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + $MyInvocation.MyCommand.Path + '"'
  if ($Background) { $a += ' -Background' }
  Start-Process powershell.exe -ArgumentList $a; exit 0
}

$ErrorActionPreference = 'Stop'
$dir   = Split-Path -Parent $MyInvocation.MyCommand.Path
$port  = 57870
$base  = "http://127.0.0.1:$port/"
$utf8  = New-Object System.Text.UTF8Encoding($false)      # UTF-8 בלי BOM
$dataF = Join-Path $dir 'luach_data.json'
$logF  = Join-Path $dir 'luach_log.txt'
$bakD  = Join-Path $dir 'backups'
$htmlF = Join-Path $dir 'luach.html'
$icoF  = Join-Path $dir 'luach.ico'

function Log([string]$m) {
  try {
    if ((Test-Path -LiteralPath $logF) -and (Get-Item -LiteralPath $logF).Length -gt 200KB) {
      $keep = Get-Content -LiteralPath $logF -Encoding UTF8 -Tail 300
      [IO.File]::WriteAllText($logF, (($keep -join "`r`n") + "`r`n"), $utf8)
    }
    [IO.File]::AppendAllText($logF, ('{0:yyyy-MM-dd HH:mm:ss} {1}' -f (Get-Date), $m) + "`r`n", $utf8)
  } catch {}
}

# גיבוי יומי: עותק אחד ליום של הנתונים כפי שהיו לפני הכתיבה הראשונה באותו יום. נשמרים 14 הימים האחרונים.
function Backup-Data {
  try {
    if (-not (Test-Path -LiteralPath $dataF)) { return }
    New-Item -ItemType Directory -Force -Path $bakD | Out-Null
    $b = Join-Path $bakD ('luach_data_{0:yyyy-MM-dd}.json' -f (Get-Date))
    if (-not (Test-Path -LiteralPath $b)) { Copy-Item -LiteralPath $dataF -Destination $b -Force }
    Get-ChildItem -LiteralPath $bakD -Filter 'luach_data_*.json' | Sort-Object Name -Descending |
      Select-Object -Skip 14 | Remove-Item -Force -ErrorAction SilentlyContinue
  } catch { Log "backup failed: $_" }
}

# ---- אם כבר רצה תוכנה - רק פותחים את הלוח ----
$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add($base)
try { $listener.Start() }
catch {
  if (-not $Background) { Start-Process $base }
  exit 0
}

Log ('started ' + $(if ($Background) { 'background' } else { 'open' }))
Backup-Data

$sync = [hashtable]::Synchronized(@{ quit = $false; test = 0 })

# ---- השרת: רץ בתהליכון נפרד, כדי שהחלק הראשי יהיה פנוי לחלונות התזכורת (חלק ב) ----
$ps = [powershell]::Create()
$ps.Runspace = [runspacefactory]::CreateRunspace()
$ps.Runspace.Open()
[void]$ps.AddScript({
  param($listener, $sync, $port, $dataF, $htmlF, $icoF, $bakD, $logF)
  $utf8 = New-Object System.Text.UTF8Encoding($false)
  function Log([string]$m) { try { [IO.File]::AppendAllText($logF, ('{0:yyyy-MM-dd HH:mm:ss} {1}' -f (Get-Date), $m) + "`r`n", $utf8) } catch {} }
  function Backup-Data {
    try {
      if (-not (Test-Path -LiteralPath $dataF)) { return }
      New-Item -ItemType Directory -Force -Path $bakD | Out-Null
      $b = Join-Path $bakD ('luach_data_{0:yyyy-MM-dd}.json' -f (Get-Date))
      if (-not (Test-Path -LiteralPath $b)) { Copy-Item -LiteralPath $dataF -Destination $b -Force }
      Get-ChildItem -LiteralPath $bakD -Filter 'luach_data_*.json' | Sort-Object Name -Descending |
        Select-Object -Skip 14 | Remove-Item -Force -ErrorAction SilentlyContinue
    } catch { Log "backup failed: $_" }
  }
  function Send($rsp, [int]$code, [string]$type, [byte[]]$bytes) {
    $rsp.StatusCode = $code
    if ($type) { $rsp.ContentType = $type }
    $rsp.Headers.Add('Cache-Control', 'no-store')
    if ($bytes -and $bytes.Length) { $rsp.ContentLength64 = $bytes.Length; $rsp.OutputStream.Write($bytes, 0, $bytes.Length) }
  }
  $okHosts = @("127.0.0.1:$port", "localhost:$port")
  $okOrig  = @("http://127.0.0.1:$port", "http://localhost:$port")

  while ($listener.IsListening) {
    try { $c = $listener.GetContext() } catch { break }
    $rq = $c.Request; $rsp = $c.Response
    try {
      # הגנה: רק בקשות מהמחשב עצמו, ורק מהדף של הלוח (ולא מאתר אחר שנפתח בדפדפן)
      $h = $rq.Headers['Host']; $o = $rq.Headers['Origin']
      if ($okHosts -notcontains $h -or ($o -and $okOrig -notcontains $o)) { Log "forbidden host=$h origin=$o"; Send $rsp 403 'text/plain' ($utf8.GetBytes('forbidden')); continue }

      $p = $rq.Url.AbsolutePath; $m = $rq.HttpMethod
      if ($m -eq 'GET' -and ($p -eq '/' -or $p -eq '/luach.html' -or $p -eq '/index.html')) {
        if (Test-Path -LiteralPath $htmlF) { Send $rsp 200 'text/html; charset=utf-8' ([IO.File]::ReadAllBytes($htmlF)) }
        else { Send $rsp 404 'text/plain; charset=utf-8' ($utf8.GetBytes('luach.html not found')) }
      }
      elseif ($m -eq 'GET' -and $p -eq '/favicon.ico') {
        if (Test-Path -LiteralPath $icoF) { Send $rsp 200 'image/x-icon' ([IO.File]::ReadAllBytes($icoF)) } else { Send $rsp 404 '' $null }
      }
      elseif ($p -eq '/api/data' -and $m -eq 'GET') {
        $b = if (Test-Path -LiteralPath $dataF) { [IO.File]::ReadAllBytes($dataF) } else { ($utf8.GetBytes('{}')) }
        Send $rsp 200 'application/json; charset=utf-8' $b
      }
      elseif ($p -eq '/api/data' -and $m -eq 'POST') {
        if ($rq.ContentLength64 -gt 5MB) { Send $rsp 413 'text/plain' ($utf8.GetBytes('too large')); continue }
        $sr = New-Object IO.StreamReader($rq.InputStream, $utf8); $body = $sr.ReadToEnd(); $sr.Close()
        # בדיקת תקינות עם JavaScriptSerializer: לא נתקע על מפתחות כפולים באותיות שונות ועל נתונים גדולים, כמו ConvertFrom-Json
        $j = $null; $perr = ''
        try {
          Add-Type -AssemblyName System.Web.Extensions
          $jss = New-Object System.Web.Script.Serialization.JavaScriptSerializer
          $jss.MaxJsonLength = [int]::MaxValue; $jss.RecursionLimit = 200
          $j = $jss.DeserializeObject($body)
        } catch { $perr = "$_" }
        if (-not $j -or $j['v'] -ne 1) { Log "save rejected (len=$($body.Length)) $perr"; Send $rsp 400 'text/plain' ($utf8.GetBytes('bad data')); continue }
        Backup-Data                                              # לפני הדריסה: גיבוי היום, אם עדיין אין
        $tmp = $dataF + '.tmp'
        [IO.File]::WriteAllText($tmp, $body, $utf8)
        Move-Item -LiteralPath $tmp -Destination $dataF -Force   # כתיבה דרך קובץ זמני, כך שקובץ חצי-כתוב לא נוצר
        $sync.dataStamp = [DateTime]::UtcNow.Ticks               # חלק ב: מסמן שהנתונים השתנו
        Send $rsp 200 'text/plain' ($utf8.GetBytes('ok'))
      }
      elseif ($p -eq '/api/test' -and $m -eq 'POST') {
        $sync.test = [int]$sync.test + 1; Log 'test requested'    # חלק ב: מקפיץ שלוש תזכורות לבדיקה
        Send $rsp 200 'text/plain' ($utf8.GetBytes('ok'))
      }
      elseif ($p -eq '/api/quit' -and $m -eq 'POST') {
        Log 'quit requested'
        Send $rsp 200 'text/plain' ($utf8.GetBytes('ok'))
        $sync.quit = $true
      }
      else { Send $rsp 404 'text/plain' ($utf8.GetBytes('not found')) }
    } catch { try { Log ("request error: $_ | line " + $_.InvocationInfo.ScriptLineNumber); $rsp.StatusCode = 500 } catch {} }
    finally { try { $rsp.Close() } catch {} }
  }
}).AddArgument($listener).AddArgument($sync).AddArgument($port).AddArgument($dataF).AddArgument($htmlF).AddArgument($icoF).AddArgument($bakD).AddArgument($logF)
$null = $ps.BeginInvoke()

if (-not $Background) { Start-Process $base }

# =====================================================================
# חלק ב: לוח עברי, מתזמן תזכורות וחלונות קופצים מונפשים
# =====================================================================
Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName PresentationCore
Add-Type -AssemblyName WindowsBase
Add-Type -AssemblyName System.Web.Extensions
$stateF = Join-Path $dir 'luach_state.json'
$jss = New-Object System.Web.Script.Serialization.JavaScriptSerializer
$jss.MaxJsonLength = [int]::MaxValue; $jss.RecursionLimit = 200

# ---------- לוח עברי (העתקה נאמנה של החישוב שבתוך luach.html) ----------
$EPOCH = -1373427; $UNIX_RD = 719163
$script:_ed = @{}; $script:_ny = @{}
function Leap([int]$y) { return ((7 * $y + 1) % 19) -lt 7 }
function LastMonth([int]$y) { if (Leap $y) { 13 } else { 12 } }
function Elapsed([int]$y) {
  if ($script:_ed.ContainsKey($y)) { return $script:_ed[$y] }
  $m = [long][math]::Floor((235 * [long]$y - 234) / 19.0)
  $parts = 12084 + 13753 * $m
  $d = 29 * $m + [long][math]::Floor($parts / 25920.0)
  if ((3 * ($d + 1)) % 7 -lt 3) { $d++ }
  $script:_ed[$y] = $d; return $d
}
function Corr([int]$y) {
  $a = Elapsed ($y - 1); $b = Elapsed $y; $c = Elapsed ($y + 1)
  if ($c - $b -eq 356) { return 2 }; if ($b - $a -eq 382) { return 1 }; return 0
}
function NewYear([int]$y) {
  if ($script:_ny.ContainsKey($y)) { return $script:_ny[$y] }
  $v = $EPOCH + (Elapsed $y) + (Corr $y); $script:_ny[$y] = $v; return $v
}
function DaysInYear([int]$y) { (NewYear ($y + 1)) - (NewYear $y) }
function MonthLen([int]$y, [int]$m) {
  if ($m -in 2, 4, 6, 10, 13) { return 29 }
  if ($m -eq 12 -and -not (Leap $y)) { return 29 }
  $dy = DaysInYear $y
  if ($m -eq 8 -and $dy % 10 -ne 5) { return 29 }
  if ($m -eq 9 -and $dy % 10 -eq 3) { return 29 }
  return 30
}
function H2F([int]$y, [int]$m, [int]$d) {
  $t = (NewYear $y) + $d - 1
  if ($m -lt 7) {
    for ($i = 7; $i -le (LastMonth $y); $i++) { $t += MonthLen $y $i }
    for ($i = 1; $i -lt $m; $i++) { $t += MonthLen $y $i }
  } else { for ($i = 7; $i -lt $m; $i++) { $t += MonthLen $y $i } }
  return $t
}
function F2H([long]$f) {
  $y = [int][math]::Floor(($f - $EPOCH) / 365.2468) + 1
  while ((NewYear $y) -gt $f) { $y-- }
  while ((NewYear ($y + 1)) -le $f) { $y++ }
  $m = if ($f -lt (H2F $y 1 1)) { 7 } else { 1 }
  while ($f -gt (H2F $y $m (MonthLen $y $m))) { $m++ }
  return @{ y = $y; m = $m; d = [int]($f - (H2F $y $m 1) + 1) }
}
function G2F([int]$y, [int]$m, [int]$d) { $dt = New-Object DateTime $y, $m, $d; return [long](($dt - [datetime]'1970-01-01').TotalDays) + $UNIX_RD }
function F2G([long]$f) { $dt = ([datetime]'1970-01-01').AddDays($f - $UNIX_RD); return @{ y = $dt.Year; m = $dt.Month; d = $dt.Day } }
function Dow([long]$f) { return [int](($f % 7 + 7) % 7) }
function ResolveMonth([int]$code, [int]$y) {
  if ($code -eq 12 -or $code -eq 13) { if (Leap $y) { return 13 } else { return 12 } }
  if ($code -eq 14) { return 12 }; return $code
}
function HFix([int]$y, [int]$code, [int]$d) { $m = ResolveMonth $code $y; return (H2F $y $m ([math]::Min($d, (MonthLen $y $m)))) }
function GLeap([int]$y) { return (($y % 4 -eq 0 -and $y % 100 -ne 0) -or $y % 400 -eq 0) }
$HM = @{ 1 = 'ניסן'; 2 = 'אייר'; 3 = 'סיון'; 4 = 'תמוז'; 5 = 'אב'; 6 = 'אלול'; 7 = 'תשרי'; 8 = 'חשוון'; 9 = 'כסלו'; 10 = 'טבת'; 11 = 'שבט'; 12 = 'אדר'; 13 = "אדר ב'" }
function HmName([int]$y, [int]$m) { if ($m -eq 12 -and (Leap $y)) { return "אדר א'" }; return $HM[$m] }
$WD = @('ראשון', 'שני', 'שלישי', 'רביעי', 'חמישי', 'שישי', 'שבת קודש')
function Gem([int]$n) {
  $ones = @('', 'א', 'ב', 'ג', 'ד', 'ה', 'ו', 'ז', 'ח', 'ט'); $tens = @('', 'י', 'כ', 'ל', 'מ', 'נ', 'ס', 'ע', 'פ', 'צ'); $hund = @('', 'ק', 'ר', 'ש')
  $s = ''
  while ($n -ge 400) { $s += 'ת'; $n -= 400 }
  if ($n -ge 100) { $s += $hund[[math]::Floor($n / 100)]; $n = $n % 100 }
  if ($n -eq 15) { $s += 'טו' } elseif ($n -eq 16) { $s += 'טז' } else { $s += $tens[[math]::Floor($n / 10)] + $ones[$n % 10] }
  if ($s.Length -eq 1) { return $s + "'" }
  return $s.Substring(0, $s.Length - 1) + '"' + $s.Substring($s.Length - 1)
}
function HebDateText([long]$f) { $h = F2H $f; return ((Gem $h.d) + ' ' + (HmName $h.y $h.m) + ' ' + (Gem ($h.y % 1000))) }
function TodayF { $n = Get-Date; return (G2F $n.Year $n.Month $n.Day) }

# ---------- קריאת נתונים ----------
function G($o, [string]$k) { if ($o -ne $null -and $o -is [System.Collections.IDictionary] -and $o.Contains($k)) { return ,$o[$k] }; return $null }   # פסיק מקדים: מונע פירוק של מערך בן איבר אחד
$script:HILULA = $null
function Get-Hilula {
  if ($script:HILULA) { return $script:HILULA }
  try {
    $t = [IO.File]::ReadAllText($htmlF, $utf8)
    $mm = [regex]::Match($t, '(?m)^\s*const HILULA=(\[.*\]);\s*$')
    if ($mm.Success) { $script:HILULA = $jss.DeserializeObject($mm.Groups[1].Value) }
  } catch { Log "hilula load failed: $_" }
  if (-not $script:HILULA) { $script:HILULA = @() }
  return $script:HILULA
}
$script:data = $null; $script:dataStamp = [datetime]::MinValue
function Load-Data {
  try {
    if (-not (Test-Path -LiteralPath $dataF)) { $script:data = $null; return }
    $st = (Get-Item -LiteralPath $dataF).LastWriteTimeUtc
    if ($st -eq $script:dataStamp -and $script:data) { return }
    $script:data = $jss.DeserializeObject([IO.File]::ReadAllText($dataF, $utf8)); $script:dataStamp = $st
  } catch { Log "data load failed: $_" }
}
function Load-State {
  $s = @{}
  try { if (Test-Path -LiteralPath $stateF) { $o = $jss.DeserializeObject([IO.File]::ReadAllText($stateF, $utf8)); if ($o) { foreach ($k in $o.Keys) { $s[$k] = $o[$k] } } } } catch { Log "state load failed: $_" }
  return $s
}
$script:state = Load-State
function Save-State {
  try {
    $cut = (Get-Date).AddDays(-10).ToString('yyyy-MM-dd')
    foreach ($k in @($script:state.Keys)) { if ($k.Length -ge 10 -and $k.Substring(0, 10) -lt $cut) { $script:state.Remove($k) } }
    [IO.File]::WriteAllText($stateF, ($script:state | ConvertTo-Json -Depth 6), $utf8)
  } catch { Log "state save failed: $_" }
}

# ---------- איסוף התזכורות ליום ----------
function PreOf($e) {
  $p = G $e 'pre'
  if ($p -is [System.Collections.IEnumerable] -and $p -isnot [string]) { return @($p | ForEach-Object { [int]$_ }) }
  $b = G $e 'before'
  if ((G $e 'remind') -ne $false -and $b -and [int]$b -gt 0) { return @([int]$b) }
  return @()
}
# האם לאירוע יש תאריך בדיוק ביום f. מחזיר רשימה של kind/yrs
function Match-Ev($e, [long]$f) {
  $out = @(); $h = F2H $f; $g = F2G $f; $trip = ((G $e 'type') -eq 'trip')
  $mode = G $e 'mode'; $hm = G $e 'hm'; $hd = G $e 'hd'; $gm = G $e 'gm'; $gd = G $e 'gd'
  if ($mode -ne 'greg' -and $hm -and $hd -and (HFix $h.y ([int]$hm) ([int]$hd)) -eq $f) {
    $hy = G $e 'hy'; $yrs = if ($hy) { $h.y - [int]$hy } else { $null }
    if ($(if ($trip) { $yrs -eq 0 } else { $yrs -eq $null -or $yrs -ge 0 })) { $out += , @{ kind = 'heb'; yrs = $yrs } }
  }
  if ($mode -ne 'heb' -and $gm -and $gd) {
    $dd = [int]$gd; if ([int]$gm -eq 2 -and $dd -eq 29 -and -not (GLeap $g.y)) { $dd = 28 }
    if ($g.m -eq [int]$gm -and $g.d -eq $dd) {
      $gy = G $e 'gy'; $yrs = if ($gy) { $g.y - [int]$gy } else { $null }
      if ($(if ($trip) { $yrs -eq 0 } else { $yrs -eq $null -or $yrs -ge 0 })) { $out += , @{ kind = 'greg'; yrs = $yrs } }
    }
  }
  return $out
}
function ShortName([string]$t) { return ($t -split '[,،]')[0].Trim() }
function HilMonth([int]$code, [int]$y, $hil) {
  if ($code -eq 12) { if (Leap $y) { if ((G $hil 'adar') -eq 'a') { return 12 } else { return 13 } } else { return 12 } }
  if ($code -eq 13) { if (Leap $y) { return 13 } else { return 12 } }
  return $code
}
function Get-DayItems([long]$today) {
  $items = @(); $d = $script:data; if (-not $d) { return $items }
  $ds = (Get-Date).ToString('yyyy-MM-dd')
  foreach ($e in (G $d 'events')) {
    if (-not $e) { continue }
    $id = [string](G $e 'id'); $type = [string](G $e 'type'); if (-not $type) { $type = 'reminder' }
    if ((G $e 'remind') -ne $false) {
      foreach ($m in (Match-Ev $e $today)) {
        $items += , @{ key = "$ds|$id|$($m.kind)"; kind = $type; name = [string](G $e 'name'); note = [string](G $e 'note'); yrs = $m.yrs; pre = 0; target = $today }
      }
    }
    foreach ($p in (PreOf $e)) {
      foreach ($m in (Match-Ev $e ($today + $p))) {
        $items += , @{ key = "$ds|$id|$($m.kind)|p$p"; kind = $type; name = [string](G $e 'name'); note = [string](G $e 'note'); yrs = $m.yrs; pre = $p; target = ($today + $p) }
      }
    }
  }
  # ימי הילולא של צדיקים שסומנו בכוכב
  $hil = G $d 'hil'
  if ((G $hil 'show') -ne $false) {
    $fav = G $d 'fav'; $hp = @(); if ($hil) { $hp = @(PreOf @{ pre = (G $hil 'pre') }) }
    $L = Get-Hilula
    for ($i = 0; $i -lt $L.Count; $i++) {
      $r = $L[$i]; $k = "$($r[0])|$($r[1])|$($r[2])"
      if ($fav -notcontains $k) { continue }
      foreach ($p in (@(0) + $hp)) {
        $f = $today + $p; $h = F2H $f; $mo = HilMonth ([int]$r[0]) $h.y $hil
        if ((H2F $h.y $mo ([math]::Min([int]$r[1], (MonthLen $h.y $mo)))) -eq $f) {
          $key = if ($p -eq 0) { "$ds|h$i|heb" } else { "$ds|h$i|heb|p$p" }
          $items += , @{ key = $key; kind = 'hilula'; name = (ShortName $r[2]); note = ''; yrs = $null; pre = $p; target = $f }
        }
      }
    }
  }
  return $items
}

function RemTime { try { $v = [string](G $script:data 'remTime'); if ($v) { return [TimeSpan]::Parse($v) } } catch {}; return [TimeSpan]'08:00' }

# ---------- תזכורות לבלוקים ממערכת השעות ----------
function TMin([string]$t) { $p = $t -split ':'; return ([int]$p[0] * 60 + [int]$p[1]) }
function Get-SchedItems {
  $items = @(); $d = $script:data; if (-not $d) { return $items }
  $now = Get-Date; $n = $now.Hour * 60 + $now.Minute; $iso = $now.ToString('yyyy-MM-dd'); $dw = [int]$now.DayOfWeek
  foreach ($it in (G (G $d 'sched') 'items')) {
    if (-not $it -or (G $it 'rem') -ne $true) { continue }
    $date = [string](G $it 'date')
    if ($date) { if ($date -ne $iso) { continue } } elseif ((G $it 'days') -notcontains $dw) { continue }
    $s = TMin ([string](G $it 'start')); $e = TMin ([string](G $it 'end')); $lead = 10; $l = G $it 'lead'; if ($l) { $lead = [int]$l }
    if ($n -ge ($s - $lead) -and $n -lt $e) {
      $items += , @{ key = "$iso|s$([string](G $it 'id'))"; kind = 'sched'; name = [string](G $it 'title'); note = [string](G $it 'note'); yrs = $null; pre = 0; target = (TodayF)
        start = [string](G $it 'start'); end = [string](G $it 'end'); color = [string](G $it 'color')
        startAt = $now.Date.AddMinutes($s).ToString('o'); endAt = $now.Date.AddMinutes($e).ToString('o') }
    }
  }
  return $items
}
function Sched-When($it) {
  $s = [datetime]::Parse([string]$it.startAt); $diff = ($s - (Get-Date)).TotalMinutes
  if ($diff -gt 1) { return ('מתחיל בעוד ' + [int][math]::Ceiling($diff) + ' דקות') }
  if ($diff -gt 0) { return 'מתחיל בעוד דקה' }
  if ($diff -gt -1) { return 'מתחיל עכשיו' }
  return ('התחיל לפני ' + [int][math]::Floor(-$diff) + ' דקות')
}

# ---------- חלון תזכורת ----------
$THEMES = @{
  birthday = @{ bg1 = '#FFF6FA'; bg2 = '#FFD0E1'; border = '#E0568A'; foot = '#FFE0EA'; title = '#C2185B'; name = '#5C0F33'; text = '#6E5862'; link = '#C2185B'; muted = '#8A5A6C' }
  yahrzeit = @{ bg1 = '#0F1B36'; bg2 = '#18294F'; border = '#B8902F'; foot = '#0B1530'; title = '#F2C14E'; name = '#FFFFFF'; text = '#C9D2E3'; link = '#F2C14E'; muted = '#9FB0CC' }
  advance  = @{ bg1 = '#FFF4DB'; bg2 = '#FFE9BC'; border = '#D98A00'; foot = '#FDE6B4'; title = '#6B3E00'; name = '#4A2B00'; text = '#7A5A2A'; link = '#8A5A00'; muted = '#8A6B3A' }
  anniv    = @{ bg1 = '#FFF8EC'; bg2 = '#FBE0C4'; border = '#C9953A'; foot = '#FAE6CE'; title = '#A33A5B'; name = '#5A2A12'; text = '#7A5A48'; link = '#A33A5B'; muted = '#8A6A55' }
  trip     = @{ bg1 = '#EAF8FB'; bg2 = '#C9EBDB'; border = '#2E9E7C'; foot = '#C6E7D8'; title = '#17604A'; name = '#0F3B2E'; text = '#3F6B5C'; link = '#17604A'; muted = '#58806F' }
  sched    = @{ bg1 = '#FBFAF6'; bg2 = '#E9EEF6'; border = '#3B82F6'; foot = '#E1E8F2'; title = '#1F3A5F'; name = '#10223A'; text = '#4A5B73'; link = '#1F3A5F'; muted = '#6B7A90' }
  reminder = @{ bg1 = '#EFF6FD'; bg2 = '#D6E7F7'; border = '#2E6DA4'; foot = '#D3E4F5'; title = '#1D4F7C'; name = '#10304F'; text = '#4A6178'; link = '#1D4F7C'; muted = '#5C7288' }
}
$TYPE_NAME = @{ birthday = 'יום הולדת'; yahrzeit = 'יום פטירה'; reminder = 'תזכורת'; hilula = 'יום הילולא'; anniversary = 'יום נישואין'; trip = 'טיול' }
$XAML = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation" xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
  Width="620" Height="480" WindowStyle="None" ResizeMode="NoResize" Topmost="True" ShowInTaskbar="True"
  AllowsTransparency="False" FlowDirection="LeftToRight" Title="לוח זמנים" FontFamily="Segoe UI" UseLayoutRounding="True">
  <Border x:Name="Bg" BorderThickness="3">
    <Grid>
      <Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="*"/><RowDefinition Height="Auto"/></Grid.RowDefinitions>
      <Border x:Name="HeadBar" Grid.Row="0" Visibility="Collapsed" Padding="0,10,0,10">
        <StackPanel FlowDirection="RightToLeft" HorizontalAlignment="Center">
          <TextBlock x:Name="HeadT" FontSize="24" FontWeight="Bold" Foreground="White" TextAlignment="Center"/>
          <TextBlock x:Name="HeadS" FontSize="15" Foreground="White" TextAlignment="Center"/>
        </StackPanel>
      </Border>
      <Canvas x:Name="Deco" Grid.Row="1" ClipToBounds="True" IsHitTestVisible="False"/>
      <Grid Grid.Row="1" x:Name="Body" Margin="14,0,14,0">
        <Grid.ColumnDefinitions><ColumnDefinition x:Name="ColL" Width="0"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions>
        <Border x:Name="Card" Grid.Column="0" Visibility="Collapsed" Width="150" Height="150" VerticalAlignment="Top" Margin="0,40,0,0" BorderThickness="2" Background="#FFFDF5">
          <StackPanel FlowDirection="RightToLeft" VerticalAlignment="Stretch">
            <Border x:Name="CardHead" Height="36"><TextBlock x:Name="CardT" Text="עוד" FontSize="19" FontWeight="Bold" Foreground="White" HorizontalAlignment="Center" VerticalAlignment="Center"/></Border>
            <TextBlock x:Name="CardN" FontSize="58" FontWeight="Bold" HorizontalAlignment="Center" Margin="0,-4,0,-6"/>
            <TextBlock x:Name="CardU" FontSize="22" FontWeight="Bold" HorizontalAlignment="Center"/>
          </StackPanel>
        </Border>
        <StackPanel x:Name="Txt" Grid.Column="1" FlowDirection="RightToLeft" VerticalAlignment="Center" Margin="10,0,10,0">
          <TextBlock x:Name="T1" FontSize="34" FontWeight="Bold" TextAlignment="Center" TextWrapping="Wrap"/>
          <TextBlock x:Name="T2" FontSize="17" TextAlignment="Center" TextWrapping="Wrap" Margin="0,4,0,0"/>
          <TextBlock x:Name="TName" FontSize="52" FontWeight="Bold" TextAlignment="Center" TextWrapping="Wrap" Margin="0,2,0,6"/>
          <TextBlock x:Name="T3" FontSize="19" TextAlignment="Center" TextWrapping="Wrap"/>
          <TextBlock x:Name="T4" FontSize="19" TextAlignment="Center" TextWrapping="Wrap"/>
        </StackPanel>
      </Grid>
      <Border x:Name="Foot" Grid.Row="2" Padding="14,0,14,0" Height="76">
        <Grid VerticalAlignment="Center">
          <Grid.ColumnDefinitions>
            <ColumnDefinition Width="Auto"/><ColumnDefinition Width="Auto"/><ColumnDefinition Width="*"/>
            <ColumnDefinition Width="Auto"/><ColumnDefinition Width="Auto"/><ColumnDefinition Width="Auto"/>
          </Grid.ColumnDefinitions>
          <TextBlock x:Name="OpenL" Grid.Column="0" FlowDirection="RightToLeft" Text="פתיחת הלוח" FontSize="17" TextDecorations="Underline" Cursor="Hand" VerticalAlignment="Center"/>
          <TextBlock x:Name="More" Grid.Column="1" FlowDirection="RightToLeft" FontSize="15" Margin="16,0,0,0" VerticalAlignment="Center"/>
          <ComboBox x:Name="Snz" Grid.Column="3" Width="112" Height="40" FontSize="17" FlowDirection="RightToLeft" VerticalContentAlignment="Center" Margin="0,0,8,0"/>
          <Button x:Name="BtnLater" Grid.Column="4" Height="48" Padding="18,0,18,0" Margin="0,0,8,0" Background="White" BorderBrush="#33414D" FontSize="18" FontWeight="Bold" Foreground="#1B2A4A"><TextBlock FlowDirection="RightToLeft" Text="הזכר לי מאוחר יותר"/></Button>
          <Button x:Name="BtnDone" Grid.Column="5" Height="48" Padding="26,0,26,0" Background="White" BorderBrush="#33414D" FontSize="18" FontWeight="Bold" Foreground="#9B1C1C"><TextBlock FlowDirection="RightToLeft" Text="בטל"/></Button>
        </Grid>
      </Border>
    </Grid>
  </Border>
</Window>
'@
function Brush([string]$hex) { return (New-Object System.Windows.Media.BrushConverter).ConvertFromString($hex) }
$script:rng = New-Object System.Random
$script:win = $null; $script:cur = $null; $script:anim = $null; $script:animTimer = $null; $script:queue = New-Object System.Collections.ArrayList
$script:queued = @{}; $script:tick = 0

function Rad($cx, $cy, $stops) {   # מברשת רדיאלית פשוטה: stops = @(@(offset,'#AARRGGBB'),...)
  $b = New-Object System.Windows.Media.RadialGradientBrush
  $b.GradientOrigin = New-Object System.Windows.Point($cx, $cy); $b.Center = New-Object System.Windows.Point($cx, $cy)
  foreach ($s in $stops) { $gs = New-Object System.Windows.Media.GradientStop; $gs.Offset = $s[0]; $gs.Color = [System.Windows.Media.ColorConverter]::ConvertFromString($s[1]); $b.GradientStops.Add($gs) }
  return $b
}
function New-Balloon($color, [double]$sc) {
  $c = New-Object System.Windows.Controls.Canvas; $c.Width = 50; $c.Height = 130
  $str = New-Object System.Windows.Shapes.Path; $str.Data = [System.Windows.Media.Geometry]::Parse('M 25,62 C 18,80 32,92 24,125')
  $str.Stroke = Brush '#99777777'; $str.StrokeThickness = 1.2; [void]$c.Children.Add($str)
  $kn = New-Object System.Windows.Shapes.Polygon; $kn.Points = [System.Windows.Media.PointCollection]'25,60 20,68 30,68'; $kn.Fill = Brush $color; [void]$c.Children.Add($kn)
  $e = New-Object System.Windows.Shapes.Ellipse; $e.Width = 48; $e.Height = 60; [System.Windows.Controls.Canvas]::SetLeft($e, 1)
  $e.Fill = Rad 0.35 0.3 @(@(0, '#FFFFFFFF'), @(0.25, $color), @(1, $color)); [void]$c.Children.Add($e)
  $hl = New-Object System.Windows.Shapes.Ellipse; $hl.Width = 11; $hl.Height = 16; $hl.Fill = Brush '#66FFFFFF'
  [System.Windows.Controls.Canvas]::SetLeft($hl, 11); [System.Windows.Controls.Canvas]::SetTop($hl, 10); [void]$c.Children.Add($hl)
  $c.RenderTransform = New-Object System.Windows.Media.ScaleTransform($sc, $sc); $c.IsHitTestVisible = $false
  return $c
}
function Build-Deco([string]$style) {
  $cv = $script:win.FindName('Deco'); $w = $cv.ActualWidth; $h = $cv.ActualHeight
  $A = @{ t = 0; rings = @(); sched = $false; balloons = @(); confetti = @(); clouds = @(); birds = @(); flame = $null; glow = $null; gl2 = $null; bell = $null }
  $cols = @('#E8456B', '#FFCB4C', '#B565E0', '#FF7FA0', '#1E8CB0', '#F0568C')
  if ($style -eq 'birthday') {
    for ($i = 0; $i -lt 6; $i++) {
      $sc = 0.8 + $script:rng.NextDouble() * 0.7
      $b = New-Balloon $cols[$i % $cols.Count] $sc
      $x = if ($i % 2 -eq 0) { 10 + $script:rng.NextDouble() * 160 } else { $w - 200 + $script:rng.NextDouble() * 160 }
      $y = $h - 20 - $script:rng.NextDouble() * ($h - 80)
      [System.Windows.Controls.Canvas]::SetLeft($b, $x); [System.Windows.Controls.Canvas]::SetTop($b, $y); [void]$cv.Children.Add($b)
      $A.balloons += , @{ el = $b; x = $x; y = $y; sp = 0.5 + $script:rng.NextDouble() * 0.9; ph = $script:rng.NextDouble() * 6.28; sw = 8 + $script:rng.NextDouble() * 10; sc = $sc }
    }
    for ($i = 0; $i -lt 34; $i++) {
      $r = New-Object System.Windows.Shapes.Rectangle; $r.Width = 5 + $script:rng.Next(0, 5); $r.Height = 3 + $script:rng.Next(0, 4)
      $cc = @('#2BC0C0', '#FFC94D', '#E8456B', '#8E6BE0', '#1E8CB0'); $r.Fill = Brush $cc[$script:rng.Next(0, 5)]
      $r.RenderTransform = New-Object System.Windows.Media.RotateTransform($script:rng.Next(0, 360)); $r.RenderTransformOrigin = '0.5,0.5'
      $x = $script:rng.NextDouble() * $w; $y = $script:rng.NextDouble() * $h
      [System.Windows.Controls.Canvas]::SetLeft($r, $x); [System.Windows.Controls.Canvas]::SetTop($r, $y); [void]$cv.Children.Add($r)
      $A.confetti += , @{ el = $r; x = $x; y = $y; v = 0.5 + $script:rng.NextDouble() * 1.3; ph = $script:rng.NextDouble() * 6.28; rot = ($script:rng.NextDouble() - 0.5) * 6 }
    }
  }
  elseif ($style -eq 'sched') {
    $col = [string]$script:cur.color; if ($col -notmatch '^#[0-9A-Fa-f]{6}$') { $col = '#3B82F6' }
    $cx = 105; $cy = [math]::Max(120, $h / 2)
    foreach ($k in 0, 1) {
      $ring = New-Object System.Windows.Shapes.Ellipse; $ring.Width = 150; $ring.Height = 150; $ring.Stroke = Brush $col; $ring.StrokeThickness = 3
      $ring.RenderTransformOrigin = '0.5,0.5'; $ring.RenderTransform = New-Object System.Windows.Media.ScaleTransform(1, 1)
      [System.Windows.Controls.Canvas]::SetLeft($ring, $cx - 75); [System.Windows.Controls.Canvas]::SetTop($ring, $cy - 75); [void]$cv.Children.Add($ring)
      $A.rings += , @{ el = $ring; ph = 0.5 * $k }
    }
    $face = New-Object System.Windows.Shapes.Ellipse; $face.Width = 150; $face.Height = 150; $face.Fill = Brush '#FFFFFF'; $face.Stroke = Brush $col; $face.StrokeThickness = 6
    [System.Windows.Controls.Canvas]::SetLeft($face, $cx - 75); [System.Windows.Controls.Canvas]::SetTop($face, $cy - 75); [void]$cv.Children.Add($face)
    for ($i = 0; $i -lt 12; $i++) {
      $a = $i * [math]::PI / 6; $r1 = if ($i % 3 -eq 0) { 55 } else { 60 }
      $tk = New-Object System.Windows.Shapes.Line; $tk.X1 = $cx + $r1 * [math]::Sin($a); $tk.Y1 = $cy - $r1 * [math]::Cos($a); $tk.X2 = $cx + 66 * [math]::Sin($a); $tk.Y2 = $cy - 66 * [math]::Cos($a)
      $tk.Stroke = Brush '#8B96A8'; $tk.StrokeThickness = $(if ($i % 3 -eq 0) { 3 } else { 1.5 }); [void]$cv.Children.Add($tk)
    }
    $tm = TMin ([string]$script:cur.start); $hAng = ((($tm / 60) % 12) + (($tm % 60) / 60)) * 30; $mAng = ($tm % 60) * 6
    foreach ($hd in @(@(38, 6, $hAng), @(56, 4, $mAng))) {
      $ln = New-Object System.Windows.Shapes.Line; $ln.X1 = $cx; $ln.Y1 = $cy; $ln.X2 = $cx; $ln.Y2 = $cy - $hd[0]
      $ln.Stroke = Brush '#1F3A5F'; $ln.StrokeThickness = $hd[1]; $ln.StrokeStartLineCap = 'Round'; $ln.StrokeEndLineCap = 'Round'
      $ln.RenderTransform = New-Object System.Windows.Media.RotateTransform($hd[2], $cx, $cy); [void]$cv.Children.Add($ln)
    }
    $dot = New-Object System.Windows.Shapes.Ellipse; $dot.Width = 12; $dot.Height = 12; $dot.Fill = Brush $col
    [System.Windows.Controls.Canvas]::SetLeft($dot, $cx - 6); [System.Windows.Controls.Canvas]::SetTop($dot, $cy - 6); [void]$cv.Children.Add($dot)
    $A.sched = $true
  }
  elseif ($style -eq 'anniv') {
    $hc = @('#E8456B', '#F28BA8', '#D9A441', '#C2185B', '#FF7FA0')
    for ($i = 0; $i -lt 14; $i++) {
      $hp = New-Object System.Windows.Shapes.Path; $hp.Data = [System.Windows.Media.Geometry]::Parse('M 0,6 C -14,-8 -26,6 0,26 C 26,6 14,-8 0,6 Z')
      $sc = 0.45 + $script:rng.NextDouble() * 0.8; $hp.Fill = Brush $hc[$i % $hc.Count]; $hp.Opacity = 0.55 + $script:rng.NextDouble() * 0.4
      $hp.RenderTransform = New-Object System.Windows.Media.ScaleTransform($sc, $sc)
      $x = $script:rng.NextDouble() * $w; $y = $script:rng.NextDouble() * $h
      [System.Windows.Controls.Canvas]::SetLeft($hp, $x); [System.Windows.Controls.Canvas]::SetTop($hp, $y); [void]$cv.Children.Add($hp)
      $A.balloons += , @{ el = $hp; x = $x; y = $y; sp = 0.4 + $script:rng.NextDouble() * 0.9; ph = $script:rng.NextDouble() * 6.28; sw = 10 + $script:rng.NextDouble() * 14; sc = $sc }
    }
  }
  elseif ($style -eq 'trip') {
    $sun = New-Object System.Windows.Shapes.Ellipse; $sun.Width = 120; $sun.Height = 120
    $sun.Fill = Rad 0.5 0.5 @(@(0, '#FFFFF2B0'), @(0.4, '#CCFFD84D'), @(1, '#00FFD84D'))
    [System.Windows.Controls.Canvas]::SetLeft($sun, $w - 120); [System.Windows.Controls.Canvas]::SetTop($sun, -20); [void]$cv.Children.Add($sun)
    $A.glow = $sun
    for ($i = 0; $i -lt 4; $i++) {
      $cl = New-Object System.Windows.Controls.Canvas; $cl.Width = 120; $cl.Height = 50
      foreach ($q in @(@(0, 18, 60, 30), @(30, 4, 56, 38), @(62, 16, 56, 32))) {
        $el = New-Object System.Windows.Shapes.Ellipse; $el.Width = $q[2]; $el.Height = $q[3]; $el.Fill = Brush '#CCFFFFFF'
        [System.Windows.Controls.Canvas]::SetLeft($el, $q[0]); [System.Windows.Controls.Canvas]::SetTop($el, $q[1]); [void]$cl.Children.Add($el)
      }
      $x = $script:rng.NextDouble() * $w; $y = 10 + $script:rng.NextDouble() * ($h * 0.55)
      [System.Windows.Controls.Canvas]::SetLeft($cl, $x); [System.Windows.Controls.Canvas]::SetTop($cl, $y); [void]$cv.Children.Add($cl)
      $A.clouds += , @{ el = $cl; x = $x; y = $y; sp = 0.15 + $script:rng.NextDouble() * 0.35; wd = 120 }
    }
    for ($i = 0; $i -lt 4; $i++) {
      $bd = New-Object System.Windows.Shapes.Path; $bd.Data = [System.Windows.Media.Geometry]::Parse('M -14,0 Q -7,-10 0,0 Q 7,-10 14,0')
      $bd.Stroke = Brush '#33505A'; $bd.StrokeThickness = 2.2; $bd.StrokeStartLineCap = 'Round'; $bd.StrokeEndLineCap = 'Round'
      $bd.RenderTransformOrigin = '0.5,1'; $sct = New-Object System.Windows.Media.ScaleTransform(1, 1); $bd.RenderTransform = $sct
      $x = $script:rng.NextDouble() * $w; $y = 30 + $script:rng.NextDouble() * ($h * 0.6)
      [System.Windows.Controls.Canvas]::SetLeft($bd, $x); [System.Windows.Controls.Canvas]::SetTop($bd, $y); [void]$cv.Children.Add($bd)
      $A.birds += , @{ el = $bd; x = $x; y = $y; y0 = $y; sp = 0.7 + $script:rng.NextDouble() * 0.8; ph = $script:rng.NextDouble() * 6.28; sct = $sct }
    }
  }
  elseif ($style -eq 'yahrzeit') {
    $cx = 105; $by = $h - 40
    $halo = New-Object System.Windows.Shapes.Ellipse; $halo.Width = 300; $halo.Height = 300
    $halo.Fill = Rad 0.5 0.5 @(@(0, '#33FFD580'), @(0.5, '#14FFD580'), @(1, '#00FFD580'))
    [System.Windows.Controls.Canvas]::SetLeft($halo, $cx - 150); [System.Windows.Controls.Canvas]::SetTop($halo, $by - 230); [void]$cv.Children.Add($halo)
    $glow = New-Object System.Windows.Shapes.Ellipse; $glow.Width = 190; $glow.Height = 190
    $glow.Fill = Rad 0.5 0.5 @(@(0, '#99FFC857'), @(0.45, '#33FFA830'), @(1, '#00FFA830'))
    [System.Windows.Controls.Canvas]::SetLeft($glow, $cx - 95); [System.Windows.Controls.Canvas]::SetTop($glow, $by - 225); [void]$cv.Children.Add($glow)
    $base = New-Object System.Windows.Shapes.Polygon; $base.Points = [System.Windows.Media.PointCollection]"$($cx - 55),$by $($cx + 55),$by $($cx + 42),$($by - 18) $($cx - 42),$($by - 18)"
    $base.Fill = Brush '#B8902F'; [void]$cv.Children.Add($base)
    $body = New-Object System.Windows.Shapes.Rectangle; $body.Width = 46; $body.Height = 150; $body.RadiusX = 3; $body.RadiusY = 3
    $lg = New-Object System.Windows.Media.LinearGradientBrush; $lg.StartPoint = '0,0'; $lg.EndPoint = '1,0'
    foreach ($s in @(@(0, '#F4E8C8'), @(0.7, '#EBDDB0'), @(1, '#CDBB88'))) { $gs = New-Object System.Windows.Media.GradientStop; $gs.Offset = $s[0]; $gs.Color = [System.Windows.Media.ColorConverter]::ConvertFromString($s[1]); $lg.GradientStops.Add($gs) }
    $body.Fill = $lg; [System.Windows.Controls.Canvas]::SetLeft($body, $cx - 23); [System.Windows.Controls.Canvas]::SetTop($body, $by - 166); [void]$cv.Children.Add($body)
    $wick = New-Object System.Windows.Shapes.Rectangle; $wick.Width = 3; $wick.Height = 14; $wick.Fill = Brush '#3A2A18'
    [System.Windows.Controls.Canvas]::SetLeft($wick, $cx - 1.5); [System.Windows.Controls.Canvas]::SetTop($wick, $by - 180); [void]$cv.Children.Add($wick)
    $fl = New-Object System.Windows.Shapes.Path
    $fl.Data = [System.Windows.Media.Geometry]::Parse('M 0,-48 C 18,-22 22,0 0,16 C -22,0 -18,-22 0,-48 Z')
    $fl.Fill = Rad 0.5 0.7 @(@(0, '#FFFFF4B8'), @(0.45, '#FFFFB52E'), @(1, '#FFE8601C'))
    $fl.RenderTransformOrigin = '0.5,1'
    $tg = New-Object System.Windows.Media.TransformGroup; $sk = New-Object System.Windows.Media.SkewTransform(0, 0); $scl = New-Object System.Windows.Media.ScaleTransform(1, 1)
    [void]$tg.Children.Add($scl); [void]$tg.Children.Add($sk); $fl.RenderTransform = $tg
    [System.Windows.Controls.Canvas]::SetLeft($fl, $cx); [System.Windows.Controls.Canvas]::SetTop($fl, $by - 182); [void]$cv.Children.Add($fl)
    $A.flame = @{ el = $fl; sk = $sk; sc = $scl }; $A.glow = $glow; $A.gl2 = $halo
  }
  elseif ($style -eq 'advance') {
    $b = New-Balloon '#EF476F' 1.0
    $x = 55; $y = $h - 150
    [System.Windows.Controls.Canvas]::SetLeft($b, $x); [System.Windows.Controls.Canvas]::SetTop($b, $y); [void]$cv.Children.Add($b)
    $A.balloons += , @{ el = $b; x = $x; y = $y; sp = 0; ph = 0; sw = 6; sc = 1.0 }
  }
  $script:anim = $A
}
function Anim-Tick {
  $A = $script:anim; if (-not $A) { return }
  $cv = $script:win.FindName('Deco'); $w = $cv.ActualWidth; $h = $cv.ActualHeight
  $A.t++; $t = $A.t
  foreach ($b in $A.balloons) {
    if ($b.sp -gt 0) { $b.y -= $b.sp; if ($b.y -lt -150) { $b.y = $h + 10 } }
    [System.Windows.Controls.Canvas]::SetTop($b.el, $b.y)
    [System.Windows.Controls.Canvas]::SetLeft($b.el, $b.x + $b.sw * [math]::Sin($t * 0.03 + $b.ph))
  }
  foreach ($c in $A.confetti) {
    $c.y += $c.v; if ($c.y -gt $h + 8) { $c.y = -8; $c.x = $script:rng.NextDouble() * $w }
    [System.Windows.Controls.Canvas]::SetTop($c.el, $c.y); [System.Windows.Controls.Canvas]::SetLeft($c.el, $c.x + 10 * [math]::Sin($t * 0.04 + $c.ph))
    $c.el.RenderTransform.Angle += $c.rot
  }
  foreach ($r in $A.rings) {
    $fr = (($t * 0.012) + $r.ph) % 1
    $r.el.RenderTransform.ScaleX = 1 + 0.4 * $fr; $r.el.RenderTransform.ScaleY = 1 + 0.4 * $fr; $r.el.Opacity = 0.65 * (1 - $fr)
  }
  if ($A.sched -and ($t % 30 -eq 0) -and $script:cur) { $script:win.FindName('T1').Text = (Sched-When $script:cur) }
  foreach ($c in $A.clouds) {
    $c.x += $c.sp; if ($c.x -gt $w + 10) { $c.x = - $c.wd }
    [System.Windows.Controls.Canvas]::SetLeft($c.el, $c.x)
  }
  foreach ($b in $A.birds) {
    $b.x -= $b.sp; if ($b.x -lt -30) { $b.x = $w + 20; $b.y0 = 30 + $script:rng.NextDouble() * ($h * 0.6) }
    $b.y = $b.y0 + 8 * [math]::Sin($t * 0.04 + $b.ph)
    [System.Windows.Controls.Canvas]::SetLeft($b.el, $b.x); [System.Windows.Controls.Canvas]::SetTop($b.el, $b.y)
    $b.sct.ScaleY = 0.25 + 0.75 * [math]::Abs([math]::Sin($t * 0.22 + $b.ph))
  }
  if ($A.glow -and -not $A.flame) { $A.glow.Opacity = 0.8 + 0.2 * [math]::Sin($t * 0.05) }
  if ($A.flame) {
    $A.flame.sc.ScaleY = 1 + 0.09 * [math]::Sin($t * 0.31) + 0.05 * [math]::Sin($t * 0.77 + 1)
    $A.flame.sc.ScaleX = 1 + 0.07 * [math]::Sin($t * 0.43) + 0.04 * [math]::Sin($t * 0.9)
    $A.flame.sk.AngleX = 7 * [math]::Sin($t * 0.21) + 3 * [math]::Sin($t * 0.6 + 2)
    $A.glow.Opacity = 0.75 + 0.2 * [math]::Sin($t * 0.27) + 0.05 * [math]::Sin($t * 0.8)
    $A.gl2.Opacity = 0.8 + 0.15 * [math]::Sin($t * 0.13)
  }
}
function Close-Popup { try { if ($script:animTimer) { $script:animTimer.Stop() } } catch {}; try { if ($script:win) { $script:win.Close() } } catch {}; $script:win = $null; $script:anim = $null }

function Show-Reminder($it) {
  $kind = [string]$it.kind; $pre = [int]$it.pre
  $style = if ($kind -eq 'sched') { 'sched' } elseif ($pre -gt 0) { 'advance' } elseif ($kind -eq 'birthday') { 'birthday' } elseif ($kind -eq 'yahrzeit' -or $kind -eq 'hilula') { 'yahrzeit' } elseif ($kind -eq 'anniversary') { 'anniv' } elseif ($kind -eq 'trip') { 'trip' } else { 'reminder' }
  $th = $THEMES[$style]
  $win = [Windows.Markup.XamlReader]::Parse($XAML)
  $script:win = $win; $script:cur = $it
  $win.FindName('Bg').BorderBrush = Brush $th.border
  $lg = New-Object System.Windows.Media.LinearGradientBrush; $lg.StartPoint = '0,0'; $lg.EndPoint = '0,1'
  foreach ($s in @(@(0, $th.bg1), @(1, $th.bg2))) { $gs = New-Object System.Windows.Media.GradientStop; $gs.Offset = $s[0]; $gs.Color = [System.Windows.Media.ColorConverter]::ConvertFromString($s[1]); $lg.GradientStops.Add($gs) }
  $win.FindName('Bg').Background = $lg
  $win.FindName('Foot').Background = Brush $th.foot
  foreach ($n in 'OpenL') { $win.FindName($n).Foreground = Brush $th.link }
  $win.FindName('More').Foreground = Brush $th.muted
  $t1 = $win.FindName('T1'); $t2 = $win.FindName('T2'); $nm = $win.FindName('TName'); $t3 = $win.FindName('T3'); $t4 = $win.FindName('T4')
  $t1.Foreground = Brush $th.title; $t2.Foreground = Brush $th.text; $nm.Foreground = Brush $th.name; $t3.Foreground = Brush $th.text; $t4.Foreground = Brush $th.text
  $name = [string]$it.name
  if ($it.yrs) { if ($kind -eq 'birthday') { $name += " ($($it.yrs))" } elseif ($kind -eq 'yahrzeit') { $name += " · $($it.yrs) שנים" } }
  $nm.Text = $name
  $todayH = HebDateText (TodayF)
  $note = [string]$it.note
  switch ($style) {
    'birthday' { $t1.Text = 'יום הולדת שמח!'; $t1.FontSize = 30; $t3.Text = $note; $t4.Text = $todayH }
    'yahrzeit' {
      $t1.Text = 'נר נשמה'; $t1.FontSize = 30; $t2.Text = 'לעילוי נשמת'
      $t3.Text = $(if ($kind -eq 'hilula') { 'יום ההילולא היום' } else { 'יום הפטירה היום' }); $t3.FontSize = 20
      $t4.Text = ($note + $(if ($note) { "`n" } else { '' }) + $todayH).Trim(); $win.FindName('ColL').Width = New-Object System.Windows.GridLength(215)
    }
    'sched' {
      $col = [string]$it.color; if ($col -notmatch '^#[0-9A-Fa-f]{6}$') { $col = '#3B82F6' }
      $lum = (0.299 * [Convert]::ToInt32($col.Substring(1, 2), 16) + 0.587 * [Convert]::ToInt32($col.Substring(3, 2), 16) + 0.114 * [Convert]::ToInt32($col.Substring(5, 2), 16))
      $fg = if ($lum -gt 165) { '#1D2433' } else { '#FFFFFF' }
      $win.FindName('Bg').BorderBrush = Brush $col
      $hb = $win.FindName('HeadBar'); $hb.Background = Brush $col; $hb.Visibility = 'Visible'
      $win.FindName('HeadT').Text = 'תזכורת ממערכת השעות'; $win.FindName('HeadT').Foreground = Brush $fg; $win.FindName('HeadS').Visibility = 'Collapsed'
      $win.FindName('ColL').Width = New-Object System.Windows.GridLength(215)
      $t1.Text = (Sched-When $it); $t1.FontSize = 28
      $t3.Text = "$($it.start) – $($it.end)"; $t3.FlowDirection = 'LeftToRight'; $t3.FontSize = 26; $t3.FontWeight = 'Bold'
      $t4.Text = $note
    }
    'anniv' {
      $t1.Text = 'יום נישואין שמח!'; $t1.FontSize = 30
      if ($it.yrs) { $t2.Text = "מלאו $($it.yrs) שנים לנישואין" }
      $t3.Text = $note; $t4.Text = $todayH
    }
    'trip' { $t1.Text = 'יוצאים לטיול!'; $t1.FontSize = 30; $t3.Text = $note; $t4.Text = $todayH }
    'reminder' { $t1.Text = 'תזכורת'; $t1.FontSize = 30; $t3.Text = $note; $t4.Text = $todayH }
    'advance' {
      $win.FindName('HeadBar').Background = Brush $th.border; $win.FindName('HeadBar').Visibility = 'Visible'
      $win.FindName('HeadT').Text = 'תזכורת מקדימה'; $win.FindName('HeadS').Text = 'האירוע עדיין לא היום'
      $cd = $win.FindName('Card'); $cd.Visibility = 'Visible'; $cd.BorderBrush = Brush $th.border; $win.FindName('CardHead').Background = Brush $th.border
      $win.FindName('CardN').Text = [string]$pre; $win.FindName('CardN').Foreground = Brush $th.name
      $win.FindName('CardU').Text = $(if ($pre -eq 1) { 'יום' } else { 'ימים' }); $win.FindName('CardU').Foreground = Brush $th.border
      $win.FindName('ColL').Width = New-Object System.Windows.GridLength(185)
      $when = switch ($pre) { 1 { 'מחר' } 2 { 'בעוד יומיים' } default { "בעוד $pre ימים" } }
      $tn = $TYPE_NAME[$kind]; if (-not $tn) { $tn = 'תזכורת' }
      $t1.Text = "$tn $when"; $t1.FontSize = 28
      $tf = [long]$it.target; $g = F2G $tf
      $t3.Text = "האירוע ביום $($WD[(Dow $tf)]), $(HebDateText $tf) · $('{0:00}.{1:00}.{2}' -f $g.d, $g.m, $g.y)"
      $t4.Text = $note
    }
  }
  foreach ($t in $t2, $t3, $t4) { if (-not $t.Text) { $t.Visibility = 'Collapsed' } }
  # כפתורים
  $snz = $win.FindName('Snz')
  if ($style -eq 'sched') { foreach ($o in '5 דקות', '10 דקות', '15 דקות', '30 דקות') { [void]$snz.Items.Add($o) }; $snz.SelectedIndex = 0 }
  else { foreach ($o in '15 דקות', 'שעה', '3 שעות', 'מחר') { [void]$snz.Items.Add($o) }; $snz.SelectedIndex = 1 }
  $rest = $script:queue.Count
  $mo = $win.FindName('More'); if ($rest -gt 0) { $mo.Text = "ועוד $rest" } else { $mo.Visibility = 'Collapsed' }
  $win.FindName('OpenL').Add_MouseLeftButtonUp({ try { Start-Process $base } catch {} })
  $win.FindName('BtnDone').Add_Click({ try { Finish-Item 'done' } catch { Log "done: $_" } })
  $win.FindName('BtnLater').Add_Click({ try { Finish-Item 'later' } catch { Log "later: $_" } })
  $win.Add_Closed({ try { if ($script:animTimer) { $script:animTimer.Stop() } } catch {} })
  $win.Add_Loaded({
    try {
      Build-Deco $script:cur.style
      $script:animTimer = New-Object System.Windows.Threading.DispatcherTimer
      $script:animTimer.Interval = [TimeSpan]::FromMilliseconds(33)
      $script:animTimer.Add_Tick({ try { Anim-Tick } catch { Log "anim: $_" } })
      $script:animTimer.Start()
    } catch { Log "deco: $_" }
  })
  $it.style = $style
  # מיקום: פינה שמאלית עליונה של המסך
  $wa = [System.Windows.SystemParameters]::WorkArea
  $win.WindowStartupLocation = 'Manual'; $win.Left = $wa.Left + 8; $win.Top = $wa.Top + 8
  Log ("popup " + $it.key)
  $win.Show(); [void]$win.Activate()
}
function Finish-Item([string]$how) {
  $it = $script:cur; $win = $script:win
  if ($it -and -not $it.test) {
    if ($how -eq 'later') {
      $sel = [string]$win.FindName('Snz').SelectedItem
      $until = switch ($sel) { '5 דקות' { (Get-Date).AddMinutes(5) } '10 דקות' { (Get-Date).AddMinutes(10) } '30 דקות' { (Get-Date).AddMinutes(30) } '15 דקות' { (Get-Date).AddMinutes(15) } '3 שעות' { (Get-Date).AddHours(3) } 'מחר' { (Get-Date).Date.AddDays(1) + (RemTime) } default { (Get-Date).AddHours(1) } }
      $copy = @{}; foreach ($k in $it.Keys) { if ($k -ne 'style') { $copy[$k] = $it[$k] } }
      $script:state[$it.key] = @{ status = 'snooze'; until = $until.ToString('o'); item = $copy }
      Log "snooze $($it.key) until $($until.ToString('HH:mm'))"
    } else { $script:state[$it.key] = @{ status = 'done' }; Log "closed $($it.key) done" }
    Save-State
  }
  if ($it) { $script:queued.Remove($it.key) }
  $script:cur = $null; Close-Popup
}

# ---------- המתזמן ----------
function Enqueue($it) { if (-not $script:queued.ContainsKey($it.key)) { $script:queued[$it.key] = $true; [void]$script:queue.Add($it) } }
$script:testSeen = 0; $script:lastScan = [datetime]::MinValue
function Scheduler-Tick {
  if ($sync.quit) { $script:app.Shutdown(); return }
  # בדיקה ידנית: שלוש תזכורות לדוגמה
  if ([int]$sync.test -gt $script:testSeen) {
    $script:testSeen = [int]$sync.test; $f = TodayF; $n = [datetime]::Now.Ticks
    Enqueue @{ key = "test|$n|1"; kind = 'birthday'; name = 'דוגמה לשם'; note = 'זו תזכורת לבדיקה'; yrs = $null; pre = 0; target = $f; test = $true }
    Enqueue @{ key = "test|$n|2"; kind = 'yahrzeit'; name = 'דוגמה לשם'; note = 'זו תזכורת לבדיקה'; yrs = $null; pre = 0; target = $f; test = $true }
    Enqueue @{ key = "test|$n|4"; kind = 'anniversary'; name = 'דוגמה לשם'; note = 'זו תזכורת לבדיקה'; yrs = 7; pre = 0; target = $f; test = $true }
    Enqueue @{ key = "test|$n|5"; kind = 'trip'; name = 'דוגמה לשם'; note = 'זו תזכורת לבדיקה'; yrs = 0; pre = 0; target = $f; test = $true }
    $sa = [datetime]::Now.AddMinutes(10)
    Enqueue @{ key = "test|$n|6"; kind = 'sched'; name = 'דוגמה: שיעור'; note = 'זו תזכורת לבדיקה'; yrs = $null; pre = 0; target = $f; test = $true; start = $sa.ToString('HH:mm'); end = $sa.AddMinutes(60).ToString('HH:mm'); color = '#3B82F6'; startAt = $sa.ToString('o'); endAt = $sa.AddMinutes(60).ToString('o') }
    Enqueue @{ key = "test|$n|3"; kind = 'birthday'; name = 'דוגמה לשם'; note = 'זו תזכורת מקדימה לבדיקה'; yrs = $null; pre = 2; target = ($f + 2); test = $true }
  }
  # סריקה כל 20 שניות
  if (([datetime]::Now - $script:lastScan).TotalSeconds -ge 20) {
    $script:lastScan = [datetime]::Now
    Load-Data
    $rt = RemTime
    if ([datetime]::Now.TimeOfDay -ge $rt) {
      foreach ($it in (Get-DayItems (TodayF))) { if (-not $script:state.ContainsKey($it.key)) { Enqueue $it } }
    }
    foreach ($it in (Get-SchedItems)) { if (-not $script:state.ContainsKey($it.key)) { Enqueue $it } }
    foreach ($k in @($script:state.Keys)) {
      $s = $script:state[$k]
      if ((G $s 'status') -eq 'snooze' -and [datetime]::Parse([string](G $s 'until')) -le [datetime]::Now -and -not $script:queued.ContainsKey($k)) {
        $it = @{}; $src = G $s 'item'; foreach ($kk in $src.Keys) { $it[$kk] = $src[$kk] }
        $it.key = $k; $script:state[$k] = @{ status = 'done' }
        if ($it.endAt -and [datetime]::Parse([string]$it.endAt) -le [datetime]::Now) { Save-State; continue }
        Enqueue $it
      }
    }
  }
  if (-not $script:win -and $script:queue.Count -gt 0) {
    $it = $script:queue[0]; $script:queue.RemoveAt(0)
    Show-Reminder $it
  }
}

# ---- החלק הראשי: מתזמן התזכורות והחלונות (תהליכון STA) ----
$script:app = New-Object System.Windows.Application
$script:app.ShutdownMode = 'OnExplicitShutdown'
$script:app.Add_DispatcherUnhandledException({ try { Log ("ui error: " + $_.Exception.Message) } catch {}; $_.Handled = $true })
$script:schedTimer = New-Object System.Windows.Threading.DispatcherTimer
$script:schedTimer.Interval = [TimeSpan]::FromSeconds(1)
$script:schedTimer.Add_Tick({ try { Scheduler-Tick } catch { Log "scheduler: $_" } })
$script:schedTimer.Start()
try { [void]$script:app.Run() }
finally {
  try { $listener.Stop(); $listener.Close() } catch {}
  Log 'stopped'
}
