@echo off
chcp 65001 >nul
rem  לוח זמנים - התקנה.  יש להריץ מתוך התיקייה שחולצה, לא מתוך ה-ZIP.
cd /d "%~dp0"
if not exist "luach_core.ps1" (
  echo.
  echo  לא נמצאו קבצי התוכנה.
  echo  יש לחלץ את כל התיקייה מה-ZIP ולהריץ מתוך התיקייה שחולצה.
  echo.
  pause
  exit /b 1
)
echo.
echo  מתקין "לוח זמנים"...
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
echo.
pause
