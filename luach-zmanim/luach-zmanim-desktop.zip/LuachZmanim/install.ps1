﻿# לוח זמנים - מתקין / מסיר.  נוצר ע"י netivdosIL
param([switch]$Uninstall)
Add-Type -AssemblyName PresentationFramework
$title   = 'לוח זמנים'
$src     = Split-Path -Parent $MyInvocation.MyCommand.Path
$inst    = Join-Path $env:LOCALAPPDATA 'Programs\LuachZmanim'
$prof    = Join-Path $env:LOCALAPPDATA 'LuachWidget'
$lnkName = 'לוח זמנים.lnk'
$oldLnks = @('לוח זמנים - ווידג''ט.lnk', 'לוח זמנים - תזכורות.lnk')
$desk    = Join-Path ([Environment]::GetFolderPath('Desktop')) $lnkName
$menu    = Join-Path ([Environment]::GetFolderPath('Programs')) $lnkName
$startup = [Environment]::GetFolderPath('Startup')
$regKey  = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\LuachZmanim'
$progFiles = 'luach_core.ps1', 'luach.html', 'widget.ps1', 'luach.ico', 'install.ps1'
$dataFiles = 'luach_data.json', 'luach_state.json'
function Msg($t, $icon = 'Information') { [void][System.Windows.MessageBox]::Show($t, $title, 'OK', $icon) }

function StopAll {
  try { Invoke-WebRequest -UseBasicParsing -Method Post -Uri 'http://127.0.0.1:57870/api/quit' -TimeoutSec 3 | Out-Null } catch {}
  Get-CimInstance Win32_Process | Where-Object { $_.ProcessId -ne $PID -and (($_.Name -like 'powershell*' -and ($_.CommandLine -like '*widget.ps1*' -or $_.CommandLine -like '*luach_core.ps1*')) -or $_.CommandLine -like '*LuachWidget*') } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
  Start-Sleep -Seconds 2
  Get-Process -Name luach -ErrorAction SilentlyContinue | Where-Object { $_.Path -like "$inst*" } | Stop-Process -Force -ErrorAction SilentlyContinue
  Start-Sleep -Milliseconds 500
}
function RemoveLinks { foreach ($f in @($desk, $menu) + ($oldLnks + $lnkName | ForEach-Object { Join-Path $startup $_ })) { Remove-Item -LiteralPath $f -ErrorAction SilentlyContinue } }

# ---------------- הסרה ----------------
if ($Uninstall) {
  $ans = [System.Windows.MessageBox]::Show("להסיר את 'לוח זמנים' מהמחשב?", $title, 'YesNo', 'Question')
  if ($ans -ne 'Yes') { exit 0 }
  $del = [System.Windows.MessageBox]::Show("למחוק גם את הנתונים שלך (אירועים, הגדרות וגיבויים)?`n`nמומלץ לבחור 'לא' - כך אפשר להתקין שוב בלי לאבד כלום.", $title, 'YesNo', 'Warning')
  StopAll; RemoveLinks
  Remove-Item -LiteralPath $regKey -Recurse -ErrorAction SilentlyContinue
  Remove-Item -LiteralPath $prof -Recurse -Force -ErrorAction SilentlyContinue
  # את התיקייה הזו (וגם הסקריפט הזה) אי אפשר למחוק בזמן שהוא רץ - מוחקים כמה שניות אחרי שהוא נסגר
  $cmd = if ($del -eq 'Yes') { "rmdir /s /q `"$inst`"" } else { ($progFiles | ForEach-Object { "del /q `"$inst\$_`"" }) -join ' & ' }
  Start-Process cmd.exe -WindowStyle Hidden -ArgumentList "/c ping -n 4 127.0.0.1 >nul & $cmd"
  Msg "'לוח זמנים' הוסר מהמחשב."
  exit 0
}

# ---------------- התקנה ----------------
if (-not (Test-Path -LiteralPath (Join-Path $src 'luach_core.ps1'))) { Msg "לא נמצא הקובץ luach_core.ps1 ליד המתקין.`nיש להפעיל את ההתקנה מהתיקייה שבה נמצאים כל קבצי התוכנה." 'Error'; exit 1 }
if (-not (Test-Path -LiteralPath (Join-Path $src 'luach.html'))) { Msg "לא נמצא הקובץ luach.html ליד המתקין." 'Error'; exit 1 }

# התיקייה הישנה (מהתקנה קודמת) - כדי להעביר ממנה את הנתונים
$old = $null
foreach ($n in $oldLnks) {
  $p = Join-Path $startup $n
  if (Test-Path -LiteralPath $p) { try { $w = (New-Object -ComObject WScript.Shell).CreateShortcut($p).WorkingDirectory; if ($w -and (Test-Path -LiteralPath (Join-Path $w 'luach_data.json'))) { $old = $w; break } } catch {} }
}

StopAll
New-Item -ItemType Directory -Force -Path $inst | Out-Null
Remove-Item -LiteralPath (Join-Path $inst 'luach.exe') -Force -ErrorAction SilentlyContinue   # נשאר מגרסה קודמת
if ($src -ne $inst) { foreach ($f in $progFiles) { $s = Join-Path $src $f; if (Test-Path -LiteralPath $s) { Copy-Item -LiteralPath $s -Destination (Join-Path $inst $f) -Force } } }

# נתונים: לא דורסים נתונים קיימים בתיקיית ההתקנה
foreach ($from in @($src, $old)) {
  if (-not $from -or $from -eq $inst) { continue }
  foreach ($f in $dataFiles) { $s = Join-Path $from $f; $d = Join-Path $inst $f; if ((Test-Path -LiteralPath $s) -and -not (Test-Path -LiteralPath $d)) { Copy-Item -LiteralPath $s -Destination $d } }
  $bk = Join-Path $from 'backups'; if ((Test-Path -LiteralPath $bk) -and -not (Test-Path -LiteralPath (Join-Path $inst 'backups'))) { Copy-Item -LiteralPath $bk -Destination (Join-Path $inst 'backups') -Recurse }
}

# קיצורי דרך: שולחן עבודה, תפריט התחל, והפעלה אוטומטית עם Windows
RemoveLinks
$sh = New-Object -ComObject WScript.Shell
function MkLnk($path) {
  $l = $sh.CreateShortcut($path)
  $l.TargetPath = 'powershell.exe'
  $l.Arguments = "-NoProfile -STA -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$inst\widget.ps1`""
  $l.WorkingDirectory = $inst
  $l.IconLocation = "$inst\luach.ico"
  $l.WindowStyle = 7
  $l.Description = 'לוח זמנים'
  $l.Save()
}
MkLnk $desk; MkLnk $menu
$auto = [System.Windows.MessageBox]::Show("להפעיל את הלוח אוטומטית עם Windows?`n`nאפשר לשנות זאת בכל עת.", $title, 'YesNo', 'Question')
if ($auto -eq 'Yes') { MkLnk (Join-Path $startup $lnkName) }

# רישום ב"הוספה/הסרה של תוכניות"
New-Item -Path $regKey -Force | Out-Null
$un = "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$inst\install.ps1`" -Uninstall"
$vals = @{ DisplayName = 'לוח זמנים'; DisplayVersion = '2.0'; Publisher = 'netivdosIL'; InstallLocation = $inst; DisplayIcon = "$inst\luach.ico"; UninstallString = $un; InstallDate = (Get-Date -Format 'yyyyMMdd') }
foreach ($k in $vals.Keys) { Set-ItemProperty -Path $regKey -Name $k -Value $vals[$k] }
Set-ItemProperty -Path $regKey -Name NoModify -Value 1 -Type DWord
Set-ItemProperty -Path $regKey -Name NoRepair -Value 1 -Type DWord
Set-ItemProperty -Path $regKey -Name EstimatedSize -Value 16000 -Type DWord

Start-Process powershell.exe -WindowStyle Hidden -WorkingDirectory $inst -ArgumentList "-NoProfile -STA -ExecutionPolicy Bypass -File `"$inst\widget.ps1`""
$migr = if ($old) { "`n• הנתונים שלך הועברו מהתיקייה הקודמת." } else { '' }
$astr = if ($auto -eq 'Yes') { "`n• התוכנה תעלה מעצמה בכל הפעלה של Windows." } else { "`n• הפעלה אוטומטית לא הוגדרה. אפשר לפתוח מקיצור הדרך." }
Msg "ההתקנה הושלמה.`n`n• הווידג'ט נפתח על שולחן העבודה.`n• תזכורות קופצות (ימי הולדת, יארצייטים, בלוקים ממערכת השעות) פועלות ברקע.`n• נוסף קיצור דרך 'לוח זמנים' בשולחן העבודה ובתפריט התחל.$astr$migr`n`nהסרה: הגדרות Windows > אפליקציות > לוח זמנים."
