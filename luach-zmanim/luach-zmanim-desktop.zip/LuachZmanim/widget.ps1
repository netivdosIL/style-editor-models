﻿# לוח זמנים - ווידג'ט צף על שולחן העבודה (חלון אמיתי בלי מסגרת, תמיד ברקע)
#   הפעלה:  widget.ps1      התקנה (עולה עם Windows):  widget.ps1 -Install      הסרה:  widget.ps1 -Remove
param([switch]$Install,[switch]$Remove,[ValidateSet('desktop','top','normal')][string]$Layer='desktop',[int]$W=300,[int]$H=420)

$dir   = Split-Path -Parent $MyInvocation.MyCommand.Path
$port  = 57870      # תוכנת הרקע של הלוח (EXE)
$wport = 57871      # השרת הקטן של הווידג'ט
$prof  = Join-Path $env:LOCALAPPDATA 'LuachWidget'
$posf  = Join-Path $prof 'pos.txt'
$logf  = Join-Path $prof 'widget.log'
$lnkName = 'לוח זמנים - ווידג''ט.lnk'
New-Item -ItemType Directory -Force -Path $prof | Out-Null
if ((Test-Path -LiteralPath $logf) -and (Get-Item -LiteralPath $logf).Length -gt 200KB) { Remove-Item -LiteralPath $logf -ErrorAction SilentlyContinue }
function Log($m) { try { Add-Content -LiteralPath $logf -Value ('{0:HH:mm:ss} {1}' -f (Get-Date), $m) } catch {} }
function KillWidget { Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -like '*LuachWidget*' -and $_.ProcessId -ne $PID } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue } }
function StopOld { Get-CimInstance Win32_Process | Where-Object { $_.ProcessId -ne $PID -and $_.Name -like 'powershell*' -and $_.CommandLine -like '*widget.ps1*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue } }

if ($Remove) { Remove-Item -LiteralPath (Join-Path ([Environment]::GetFolderPath('Startup')) $lnkName) -ErrorAction SilentlyContinue; StopOld; KillWidget; exit 0 }
if ($Install) {
  StopOld; KillWidget
  $sh = New-Object -ComObject WScript.Shell
  $l = $sh.CreateShortcut((Join-Path ([Environment]::GetFolderPath('Startup')) $lnkName))
  $l.TargetPath = 'powershell.exe'
  $l.Arguments = "-NoProfile -STA -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$PSCommandPath`" -Layer $Layer"
  $l.WorkingDirectory = $dir
  $ico = Join-Path $dir 'luach.ico'; if (Test-Path -LiteralPath $ico) { $l.IconLocation = $ico }
  $l.Save()
  Start-Process powershell.exe -WindowStyle Hidden -ArgumentList "-NoProfile -STA -ExecutionPolicy Bypass -File `"$PSCommandPath`" -Layer $Layer"
  exit 0
}

Add-Type @'
using System; using System.Runtime.InteropServices;
public class LW {
  [StructLayout(LayoutKind.Sequential)] public struct RECT { public int L, T, R, B; }
  [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
  [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr h, IntPtr a, int x, int y, int cx, int cy, uint f);
  [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
  [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr h);
  [DllImport("user32.dll")] public static extern bool IsWindow(IntPtr h);
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern IntPtr FindWindow(string c, string t);
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int c);
  [DllImport("user32.dll")] public static extern bool SetLayeredWindowAttributes(IntPtr h, uint k, byte a, uint f);
  [DllImport("user32.dll", EntryPoint="GetWindowLongPtrW")] static extern IntPtr GetWLP(IntPtr h, int i);
  [DllImport("user32.dll", EntryPoint="SetWindowLongPtrW")] static extern IntPtr SetWLP(IntPtr h, int i, IntPtr v);
  [DllImport("user32.dll")] public static extern uint GetDpiForSystem();
  [DllImport("user32.dll")] public static extern short GetAsyncKeyState(int k);
  public static void Style(IntPtr h, long add, long remove, bool ex) { int i = ex ? -20 : -16; long v = (long)GetWLP(h, i); v = (v | add) & ~remove; SetWLP(h, i, (IntPtr)v); }
  public static void Alpha(IntPtr h, int pct) { if (pct < 100) Style(h, 0x80000, 0, true); SetLayeredWindowAttributes(h, 0, (byte)(255 * pct / 100), 2); }
}
'@
[void][LW]::SetProcessDPIAware()      # קואורדינטות פיזיות - הזזה וגודל מדויקים
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
StopOld; KillWidget; Start-Sleep -Milliseconds 700
Log "--- start v5 layer=$Layer ps=$($PSVersionTable.PSVersion) sta=$([Threading.Thread]::CurrentThread.GetApartmentState())"

$sync = [hashtable]::Synchronized(@{ hwnd = [IntPtr]::Zero; pinned = $false; alpha = 100; quit = $false; act = [long]0 })

# 1. תוכנת הרקע של הלוח צריכה לרוץ (היא שומרת את הנתונים והתזכורות)
function Up { try { (Invoke-WebRequest -UseBasicParsing -Uri "http://127.0.0.1:$port/" -TimeoutSec 2).StatusCode -eq 200 } catch { $false } }
if (-not (Up)) {
  $core = Join-Path $dir 'luach_core.ps1'
  if (Test-Path -LiteralPath $core) { Start-Process -FilePath 'powershell.exe' -WindowStyle Hidden -WorkingDirectory $dir -ArgumentList "-NoProfile -STA -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$core`" -Background" }
  for ($i = 0; $i -lt 60 -and -not (Up); $i++) { Start-Sleep -Seconds 1 }
}

# 2. שרת קטן: מגיש את luach.html מהתיקייה ומעביר /api לתוכנת הרקע (התוכנה ברקע מגישה עותק משלה)
$html = Join-Path $dir 'luach.html'
$ps = [powershell]::Create(); $ps.Runspace = [runspacefactory]::CreateRunspace(); $ps.Runspace.Open()
[void]$ps.AddScript({
  param($html, $wport, $port, $sync)
  $l = New-Object System.Net.HttpListener
  $l.Prefixes.Add("http://127.0.0.1:$wport/")
  try { $l.Start() } catch { return }
  while ($l.IsListening) {
    $c = $l.GetContext(); $rq = $c.Request; $rsp = $c.Response
    try {
      $p = $rq.Url.AbsolutePath
      if ($p -eq '/' -or $p -eq '/luach.html' -or $p -eq '/index.html') {
        $b = [IO.File]::ReadAllBytes($html)
        $rsp.ContentType = 'text/html; charset=utf-8'; $rsp.Headers.Add('Cache-Control', 'no-store')
        $rsp.OutputStream.Write($b, 0, $b.Length)
      }
      else {
        $q = [Net.HttpWebRequest]::Create("http://127.0.0.1:$port" + $rq.Url.PathAndQuery)
        $q.Method = $rq.HttpMethod; $q.Timeout = 15000
        if ($rq.HasEntityBody) {
          $ms = New-Object IO.MemoryStream; $rq.InputStream.CopyTo($ms); $bytes = $ms.ToArray()
          $q.ContentType = $rq.ContentType; $q.ContentLength = $bytes.Length
          $st = $q.GetRequestStream(); $st.Write($bytes, 0, $bytes.Length); $st.Close()
        } elseif ($rq.HttpMethod -ne 'GET') { $q.ContentLength = 0 }
        try { $r = $q.GetResponse() } catch [Net.WebException] { $r = $_.Exception.Response }
        $rsp.StatusCode = [int]$r.StatusCode
        if ($r.ContentType) { $rsp.ContentType = $r.ContentType }
        $ms2 = New-Object IO.MemoryStream; $r.GetResponseStream().CopyTo($ms2); $o = $ms2.ToArray()
        $rsp.OutputStream.Write($o, 0, $o.Length); $r.Close()
      }
    } catch { try { $rsp.StatusCode = 502 } catch {} }
    try { $rsp.Close() } catch {}
  }
}).AddArgument($html).AddArgument($wport).AddArgument($port).AddArgument($sync)
[void]$ps.BeginInvoke()
$own = $false
for ($i = 0; $i -lt 10 -and -not $own; $i++) { Start-Sleep -Milliseconds 500; try { $own = (Invoke-WebRequest -UseBasicParsing -Uri "http://127.0.0.1:$wport/" -TimeoutSec 2).StatusCode -eq 200 } catch {} }
Log "own server up: $own"
$url = if ($own -and (Test-Path -LiteralPath $html)) { "http://127.0.0.1:$wport/#widget" } else { "http://127.0.0.1:$port/#widget" }

# 3. מצב שמור (מיקום, גודל, קיבוע, שקיפות) או ברירת מחדל: פינה ימנית-עליונה
$scale = 1.0; try { $scale = [LW]::GetDpiForSystem() / 96.0 } catch {}
$pw = [int]($W * $scale); $ph = [int]($H * $scale)
$wa = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea
$px = $wa.Right - $pw - 24; $py = $wa.Top + 24; $pinned0 = $false; $alpha0 = 100
if (Test-Path -LiteralPath $posf) {
  $a = (Get-Content -LiteralPath $posf -Raw).Trim().Split(',')
  if ($a.Count -ge 6) { $px = [int]$a[0]; $py = [int]$a[1]; $pw = [int]$a[2]; $ph = [int]$a[3]; $pinned0 = ($a[4] -eq '1'); $alpha0 = [int]$a[5] }
}
$vs = [System.Windows.Forms.SystemInformation]::VirtualScreen   # אם המסך השתנה - מחזירים לתוך המסך
if ($px -lt $vs.Left - 50 -or $px -gt $vs.Right - 80 -or $py -lt $vs.Top - 10 -or $py -gt $vs.Bottom - 80) { $px = $wa.Right - $pw - 24; $py = $wa.Top + 24 }
if ($pw -lt 150 -or $ph -lt 150) { $pw = [int]($W * $scale); $ph = [int]($H * $scale) }

# 4. WebView2: חלון אמיתי בלי מסגרת. דורש את WebView2 Runtime (מותקן עם Edge) וקבצי הספרייה (יורדים פעם אחת)
function WV2Runtime {
  foreach ($k in 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}','HKLM:\SOFTWARE\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}','HKCU:\SOFTWARE\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}') {
    try { $v = (Get-ItemProperty -LiteralPath $k -ErrorAction Stop).pv; if ($v -and $v -ne '0.0.0.0') { return $v } } catch {}
  }
  return $null
}
function WV2Lib {
  $lib = Join-Path $prof 'wv2lib'; $core = Join-Path $lib 'Microsoft.Web.WebView2.Core.dll'
  if (-not (Test-Path -LiteralPath $core)) {
    try {
      Log 'downloading WebView2 libraries'
      [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
      $zip = Join-Path $prof 'wv2.zip'; $tmp = Join-Path $prof 'wv2tmp'
      Invoke-WebRequest -UseBasicParsing -Uri 'https://www.nuget.org/api/v2/package/Microsoft.Web.WebView2' -OutFile $zip
      Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue
      Add-Type -AssemblyName System.IO.Compression.FileSystem
      [IO.Compression.ZipFile]::ExtractToDirectory($zip, $tmp)
      New-Item -ItemType Directory -Force -Path $lib | Out-Null
      Copy-Item -Path (Join-Path $tmp 'lib\net462\*.dll') -Destination $lib -Force
      Copy-Item -Path (Join-Path $tmp 'runtimes\win-x64\native\WebView2Loader.dll') -Destination $lib -Force
      Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue; Remove-Item -LiteralPath $zip -Force -ErrorAction SilentlyContinue
    } catch { Log "download failed: $_" }
  }
  if (Test-Path -LiteralPath $core) { return $lib } else { return $null }
}
$rt = WV2Runtime; $lib = $null
if ($rt) { $lib = WV2Lib }
Log "webview2 runtime=$rt lib=$lib"

if ($rt -and $lib) {
  try {
    $env:PATH = "$lib;$env:PATH"
    Add-Type -Path (Join-Path $lib 'Microsoft.Web.WebView2.Core.dll')
    Add-Type -Path (Join-Path $lib 'Microsoft.Web.WebView2.WinForms.dll')
    $st = @{ ready = $false; fallback = $false; drag = $false; size = $false; cx = 0; cy = 0; fx = 0; fy = 0; fw = 0; fh = 0; pinned = $pinned0; alpha = $alpha0; act = [long]0 }
    $form = New-Object System.Windows.Forms.Form
    $form.FormBorderStyle = 'None'; $form.ShowInTaskbar = $false; $form.StartPosition = 'Manual'
    $form.Bounds = New-Object System.Drawing.Rectangle($px, $py, $pw, $ph)
    $form.BackColor = [System.Drawing.Color]::FromArgb(24, 48, 79)
    $form.Opacity = [Math]::Max(0.3, $alpha0 / 100.0); $form.Text = 'לוח זמנים'
    $form.MinimumSize = New-Object System.Drawing.Size([int](170 * $scale), [int](150 * $scale))
    if ($Layer -eq 'top') { $form.TopMost = $true }
    try { $icoP = Join-Path $dir 'luach.ico'; if (Test-Path -LiteralPath $icoP) { $form.Icon = New-Object System.Drawing.Icon($icoP) } } catch {}
    $wv = New-Object Microsoft.Web.WebView2.WinForms.WebView2
    $cp = New-Object Microsoft.Web.WebView2.WinForms.CoreWebView2CreationProperties
    $cpArgs = '--autoplay-policy=no-user-gesture-required'   # צליל התזכורת
    $cp.UserDataFolder = Join-Path $prof 'wv2data'; $cp.AdditionalBrowserArguments = $cpArgs; $wv.CreationProperties = $cp
    $wv.Dock = 'Fill'; $form.Controls.Add($wv)

    # חלון נפרד ללא מסגרת למערכת השעות: נגרר מהשורה העליונה, גודלו משתנה מהפינה, ויש בו מזעור / הגדלה / סגירה
    $st.sd = @{ max = $false; nb = $null; drag = $false; size = $false; cx = 0; cy = 0; fx = 0; fy = 0; fw = 0; fh = 0 }
    $onMsg2 = {
      param($s, $e)
      try {
        $f = $st.sform; $d = $st.sd; if (-not $f -or $f.IsDisposed) { return }
        switch ($e.TryGetWebMessageAsString()) {
          'drag0' { if ($f.WindowState -eq 'Normal' -and -not $d.max) { $c = [System.Windows.Forms.Cursor]::Position; $d.cx = $c.X; $d.cy = $c.Y; $d.fx = $f.Left; $d.fy = $f.Top; $d.drag = $true } }
          'drag1' { $d.drag = $false }
          'size0' { if ($f.WindowState -eq 'Normal' -and -not $d.max) { $c = [System.Windows.Forms.Cursor]::Position; $d.cx = $c.X; $d.cy = $c.Y; $d.fw = $f.Width; $d.fh = $f.Height; $d.size = $true } }
          'size1' { $d.size = $false }
          'smin'  { $f.WindowState = 'Minimized' }
          'smax'  {   # הגדלה ידנית לאזור העבודה - לא מכסה את שורת המשימות
            if ($d.max) { $f.Bounds = $d.nb; $d.max = $false }
            else { $d.nb = $f.Bounds; $f.Bounds = [System.Windows.Forms.Screen]::FromControl($f).WorkingArea; $d.max = $true }
          }
          'sclose' { $f.Close() }
        }
      } catch { Log "schedule msg: $_" }
    }
    function OpenSchedule {
      try {
        if ($st.sform -and -not $st.sform.IsDisposed) { $st.sform.WindowState = 'Normal'; $st.sform.Activate(); return }
        $f2 = New-Object System.Windows.Forms.Form
        $f2.Text = 'מערכת שעות'; $f2.FormBorderStyle = 'None'; $f2.StartPosition = 'CenterScreen'; $f2.ShowInTaskbar = $true
        $wa3 = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea
        $f2.BackColor = [System.Drawing.Color]::FromArgb(244, 241, 234)
        $f2.MinimumSize = New-Object System.Drawing.Size([int](700 * $scale), [int](460 * $scale))
        $f2.Size = New-Object System.Drawing.Size([Math]::Min([int](1100 * $scale), $wa3.Width - 40), [Math]::Min([int](780 * $scale), $wa3.Height - 40))
        if ($form.Icon) { $f2.Icon = $form.Icon }
        $cp2 = New-Object Microsoft.Web.WebView2.WinForms.CoreWebView2CreationProperties
        $cp2.UserDataFolder = $cp.UserDataFolder; $cp2.AdditionalBrowserArguments = $cpArgs
        $w2 = New-Object Microsoft.Web.WebView2.WinForms.WebView2
        $w2.CreationProperties = $cp2; $w2.Dock = 'Fill'
        $w2.add_CoreWebView2InitializationCompleted({
          param($s3, $e3)
          try { if ($e3.IsSuccess) { $s3.CoreWebView2.Settings.AreDefaultContextMenusEnabled = $false; $s3.CoreWebView2.add_WebMessageReceived($onMsg2) } else { Log "schedule init failed: $($e3.InitializationException)" } } catch { Log "schedule setup: $_" }
        })
        $w2.Source = [Uri](($url.Split('#')[0]) + '#schedule')
        $f2.Controls.Add($w2)
        $tm = New-Object System.Windows.Forms.Timer; $tm.Interval = 12
        $tm.Add_Tick({
          try {
            $f = $st.sform; $d = $st.sd; if (-not $f -or $f.IsDisposed -or -not ($d.drag -or $d.size)) { return }
            if (([LW]::GetAsyncKeyState(1) -band 0x8000) -eq 0) { $d.drag = $false; $d.size = $false; return }
            $c = [System.Windows.Forms.Cursor]::Position
            if ($d.drag) { $f.Location = New-Object System.Drawing.Point(($d.fx + $c.X - $d.cx), ($d.fy + $c.Y - $d.cy)) }
            if ($d.size) { $f.Size = New-Object System.Drawing.Size([Math]::Max($f.MinimumSize.Width, $d.fw + $c.X - $d.cx), [Math]::Max($f.MinimumSize.Height, $d.fh + $c.Y - $d.cy)) }
          } catch { Log "schedule tick: $_" }
        })
        $st.stimer = $tm
        $f2.Add_FormClosed({ $st.sd.max = $false; try { $st.stimer.Stop(); $st.stimer.Dispose() } catch {}; $st.sform = $null })
        $st.sform = $f2
        $tm.Start(); $f2.Show(); $f2.Activate()
        Log 'schedule window opened'
      } catch { Log "schedule: $_" }
    }
    # סמל במגש המערכת: התראות תזכורת + פתיחת מערכת השעות
    $ni = New-Object System.Windows.Forms.NotifyIcon
    try { if ($form.Icon) { $ni.Icon = $form.Icon } } catch {}
    if (-not $ni.Icon) { $ni.Icon = [System.Drawing.SystemIcons]::Application }
    $ni.Text = 'לוח זמנים'
    $ms = New-Object System.Windows.Forms.ContextMenuStrip
    [void]$ms.Items.Add('מערכת שעות שבועית', $null, [EventHandler]{ OpenSchedule })
    [void]$ms.Items.Add('יציאה', $null, [EventHandler]{ $form.Close() })
    $ni.ContextMenuStrip = $ms
    $ni.add_DoubleClick({ OpenSchedule })
    $ni.Visible = $true

    function Push {
      try {
        $pin = if ($st.pinned) { 'true' } else { 'false' }
        $j = "{`"x`":$($form.Left),`"y`":$($form.Top),`"w`":$($form.Width),`"h`":$($form.Height),`"pinned`":$pin,`"alpha`":$($st.alpha)}"
        $wv.CoreWebView2.PostWebMessageAsString($j)
      } catch { Log "push: $_" }
    }
    function SaveForm {
      try { $pn = if ($st.pinned) { 1 } else { 0 }; "$($form.Left),$($form.Top),$($form.Width),$($form.Height),$pn,$($st.alpha)" | Set-Content -LiteralPath $posf } catch {}
    }
    $onMsg = {
      param($s, $e)
      try {
        $m = $e.TryGetWebMessageAsString(); $path = $m; $qs = @{}
        if ($m.Contains('?')) { $parts = $m.Split('?', 2); $path = $parts[0]; foreach ($kv in $parts[1].Split('&')) { $kvp = $kv.Split('='); if ($kvp.Count -ge 2) { $qs[$kvp[0]] = $kvp[1] } } }
        $st.act = [DateTime]::UtcNow.Ticks
        switch ($path) {
          'drag0' { if (-not $st.pinned) { $c = [System.Windows.Forms.Cursor]::Position; $st.cx = $c.X; $st.cy = $c.Y; $st.fx = $form.Left; $st.fy = $form.Top; $st.drag = $true } }
          'drag1' { $st.drag = $false; SaveForm }
          'size0' { if (-not $st.pinned) { $c = [System.Windows.Forms.Cursor]::Position; $st.cx = $c.X; $st.cy = $c.Y; $st.fw = $form.Width; $st.fh = $form.Height; $st.size = $true } }
          'size1' { $st.size = $false; SaveForm; Push }
          'size'  {
            $wa2 = [System.Windows.Forms.Screen]::FromControl($form).WorkingArea      # אף פעם לא יותר גדול מהמסך
            $nw = [Math]::Min([Math]::Max($form.MinimumSize.Width, [int]$qs['w']), $wa2.Width)
            $nh = [Math]::Min([Math]::Max($form.MinimumSize.Height, [int]$qs['h']), $wa2.Height)
            $form.Size = New-Object System.Drawing.Size($nw, $nh)
            $nx = [Math]::Max($wa2.Left, [Math]::Min($form.Left, $wa2.Right - $nw)); $ny = [Math]::Max($wa2.Top, [Math]::Min($form.Top, $wa2.Bottom - $nh))
            $form.Location = New-Object System.Drawing.Point($nx, $ny)
            SaveForm; Push }
          'pin'   { $st.pinned = ($qs['on'] -eq '1'); SaveForm; Push }
          'alpha' { $st.alpha = [int]$qs['v']; $form.Opacity = [Math]::Max(0.3, $st.alpha / 100.0); SaveForm; Push }
          'full'  { Start-Process "http://127.0.0.1:$wport/" }
          'quit'  { $form.Close() }
          'schedule' { OpenSchedule }
          'toast' { $ni.ShowBalloonTip(10000, 'לוח זמנים', [Uri]::UnescapeDataString([string]$qs['t']), [System.Windows.Forms.ToolTipIcon]::Info) }
          'state' { Push }
        }
      } catch { Log "msg error: $_" }
    }
    $wv.add_CoreWebView2InitializationCompleted({
      param($s, $e)
      if (-not $e.IsSuccess) { Log "webview2 init failed: $($e.InitializationException)"; $st.fallback = $true; $form.Close(); return }
      try {
        $c = $wv.CoreWebView2
        $c.Settings.AreDefaultContextMenusEnabled = $false
        $c.Settings.IsZoomControlEnabled = $false
        $c.Settings.IsStatusBarEnabled = $false
        $c.add_WebMessageReceived($onMsg)
        $c.add_NavigationCompleted({ param($s2, $a2) if ($a2.IsSuccess) { $st.ready = $true; Log 'page loaded' }; Push })
        Log 'webview2 ready'
      } catch { Log "webview2 setup: $_" }
    })
    $wv.Source = [Uri]$url

    # גרירה ושינוי גודל לפי מיקום העכבר, וחזרה לרקע
    $t1 = New-Object System.Windows.Forms.Timer; $t1.Interval = 12
    $t1.Add_Tick({
      try {
        if (-not ($st.drag -or $st.size)) { return }
        if (([LW]::GetAsyncKeyState(1) -band 0x8000) -eq 0) { $st.drag = $false; $st.size = $false; SaveForm; return }
        $c = [System.Windows.Forms.Cursor]::Position
        if ($st.drag) { $form.Location = New-Object System.Drawing.Point(($st.fx + $c.X - $st.cx), ($st.fy + $c.Y - $st.cy)) }
        if ($st.size) { $form.Size = New-Object System.Drawing.Size([Math]::Max($form.MinimumSize.Width, $st.fw + $c.X - $st.cx), [Math]::Max($form.MinimumSize.Height, $st.fh + $c.Y - $st.cy)) }
      } catch { Log "tick: $_" }
    })
    $n = 0
    $t2 = New-Object System.Windows.Forms.Timer; $t2.Interval = 1000
    $t2.Add_Tick({
      try {
        $script:n++
        $h = $form.Handle
        if ([LW]::IsIconic($h)) { [void][LW]::ShowWindow($h, 4) }     # Win+D - מחזירים
        $busy = $st.drag -or $st.size -or (([DateTime]::UtcNow.Ticks - $st.act) -lt 20000000)
        if ($Layer -eq 'desktop' -and -not $busy) { [void][LW]::SetWindowPos($h, [IntPtr]1, 0, 0, 0, 0, 0x13) }
        if ($script:n % 10 -eq 0) { SaveForm }
      } catch { Log "tick2: $_" }
    })
    $t3 = New-Object System.Windows.Forms.Timer; $t3.Interval = 25000
    $t3.Add_Tick({ $t3.Stop(); if (-not $st.ready) { Log 'webview2 page not loaded after 25s - falling back'; $st.fallback = $true; $form.Close() } })
    $form.Add_Shown({ $t3.Start(); $t1.Start(); $t2.Start(); Log "form shown at $($form.Left),$($form.Top) $($form.Width)x$($form.Height)" })
    $form.Add_FormClosing({ SaveForm; $t1.Stop(); $t2.Stop(); try { $ni.Visible = $false; $ni.Dispose(); if ($st.sform -and -not $st.sform.IsDisposed) { $st.sform.Close() } } catch {}; Log 'closing' })
    [System.Windows.Forms.Application]::Run($form)
    Log 'end (webview2)'
    KillWidget
    if (-not $st.fallback) { exit 0 }
  } catch { Log "webview2 mode failed, falling back to Edge window: $_" }
}

# 5. גיבוי: חלון Edge (עם שורת כותרת רגילה). הדף עצמו מזיז ומשנה גודל; כאן רק שומרים אותו ברקע
$br = @("${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe","$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe","$env:ProgramFiles\Google\Chrome\Application\chrome.exe","${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe") | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
if (-not $br) { [void][System.Windows.Forms.MessageBox]::Show('לא נמצא WebView2, Microsoft Edge או Chrome.','לוח זמנים'); exit 1 }
$dx = [int]($px / $scale); $dy = [int]($py / $scale)
Start-Process -FilePath $br -ArgumentList "--app=$url","--user-data-dir=`"$prof\browser`"","--window-size=$W,$H","--window-position=$dx,$dy","--no-first-run"
Log "edge window: $br"
$miss = 0; $tick = 0; $hw = [IntPtr]::Zero
while ($true) {
  Start-Sleep -Seconds 1; $tick++
  try {
    if ($hw -eq [IntPtr]::Zero -or -not [LW]::IsWindow($hw)) {
      $hw = [LW]::FindWindow($null, 'לוח זמנים')
      if ($hw -eq [IntPtr]::Zero) { $miss++; if ($miss -ge 40 -and $miss % 10 -eq 0 -and -not (Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -like '*LuachWidget*' } | Select-Object -First 1)) { break }; continue }
      $miss = 0; Log "edge window handle $hw"
    }
    if ([LW]::IsIconic($hw)) { [void][LW]::ShowWindow($hw, 4) }
    if ($Layer -eq 'top') { [void][LW]::SetWindowPos($hw, [IntPtr]-1, 0, 0, 0, 0, 0x13) }
    elseif ($Layer -eq 'desktop' -and $tick -gt 4) { [void][LW]::SetWindowPos($hw, [IntPtr]1, 0, 0, 0, 0, 0x13) }
  } catch { Log "loop error: $_" }
}
Log 'end (edge)'
