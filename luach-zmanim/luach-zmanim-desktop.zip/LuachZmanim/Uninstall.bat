@echo off
chcp 65001 >nul
rem  לוח זמנים - הסרה
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1" -Uninstall
